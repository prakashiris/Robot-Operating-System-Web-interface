function displaySuccess(message) {
  var html = '<div class="alert alert-success">'
    + message
    + '</div>';
  $('#messages').html(html);
}
