/**
 * @author Russell Toris - rctoris@wpi.edu
 */

/**
 * Manages connection to the server and all interactions with ROS.
 *
 * Emits the following events:
 *   * 'change' - emitted with a change in speed occurs
 *
 * @constructor
 * @param options - possible keys include:
 *   * ros - the ROSLIB.Ros connection handle
 *   * topic (optional) - the Twist topic to publish to, like '/cmd_vel'
 *   * throttle (optional) - a constant throttle for the speed
 */


KEYBOARDTELEOP.Teleop = function(options) {
  var that = this;
  options = options || {};
  var ros = options.ros;
  var topic = options.topic || '/cmd_vel';
  
  // used to externally throttle the speed (e.g., from a slider)
  var new_speed_x,speed_x,last_speed_x = 0.5;
  var new_speed_z,speed_z,last_speed_z = 1.0;
  var last_key = 0;
  // linear x and y movement and angular z movement
  var x = 0;
  var y = 0;
  var z = 0;
  
  var cmdVel = new ROSLIB.Topic({
    ros : ros,
    name : topic,
    messageType : 'geometry_msgs/Twist'
  });


  // sets up a key listener on the page used for keyboard teleoperation
  this.handleKey = function(keyCode, keyDown) {
    // used to check for changes in speed
    var oldX = x;
    var oldY = y;
    var oldZ = z;
    
    var pub = true;
    // Linear and angular function
    switch (keyCode) {
      //increase linear and angular
      case 81:
          if(keyCode == 81 && keyDown === true){
          new_speed_x = new_speed_x + (new_speed_x/10);
          new_speed_z = new_speed_z + (new_speed_z/10);
          speed_x = new_speed_x;
          speed_z = new_speed_z;
          }
          break;
      //decrease linear and angular
      case 90:
          if(keyCode == 90 && keyDown === true){
          new_speed_x = new_speed_x - (new_speed_x/10);
          new_speed_z = new_speed_z - (new_speed_z/10);
          speed_x = new_speed_x;
          speed_z = new_speed_z;
          }
          break;
       //increase linear 
       case 87:
          if(keyCode == 87 && keyDown === true){
          new_speed_x = new_speed_x + (new_speed_x/10);
          speed_x = new_speed_x;
          }
          break;
      //decrease linear 
       case 88:
          if(keyCode == 88 && keyDown === true){
            new_speed_x = new_speed_x - (new_speed_x/10);
            speed_x = new_speed_x;
          } 
          break;
      //increase angular 
      case 69:
          if(keyCode == 69 && keyDown === true){
          new_speed_z = new_speed_z + (new_speed_z/10);
          speed_z = new_speed_z;
          }
          break;
      //decrease angular 
      case 67:
          if(keyCode == 67 && keyDown === true){
          new_speed_z = new_speed_z - (new_speed_z/10);
          speed_z = new_speed_z;
          }
           break;
    }
    //Check the previous key and the functional speed will be fixed
    if (Math.abs(last_speed_x) != Math.abs(speed_x)){
      // Up and Down arrow key continue with all rotation key
      if (last_key == 73 || last_key == 188 || last_key == 85 || last_key == 79 || last_key == 77 || last_key == 190){
        keyCode = last_key
      }
    }
    if (Math.abs(last_speed_z) != Math.abs(speed_z)){
      // Left and Right arrow key continue with all rotation key
      if (last_key == 74 || last_key == 76 || last_key == 85 || last_key == 79 || last_key == 77 || last_key == 190){
        keyCode = last_key
      }
    }
    // control  Key function
    switch (keyCode) {
      case 73:
        // up
        x = new_speed_x;
        z=0;
        last_key =73;
        break;
      case 74:
        // turn left
        x=0;
        z = new_speed_z;
        last_key = 74;
        break;
      case 76:
        // turn right
        x=0;
         z = -new_speed_z;
        last_key = 76;
         break;
      case 188:
      // down//comma
        x = -new_speed_x;
        z=0;
        last_key = 188;
        break;
      case 75:
          //stop
          x = 0;
          z = 0;      
          last_key = 75;
          break;
      case 85:
          //forward left
          x = new_speed_x;
          z = new_speed_z;
          last_key = 85;
         break;
      case 79:
          //forward right
          x = new_speed_x;
          z = -new_speed_z;
          last_key = 79;
          break;
      case 77:
          //backward left
          x = -new_speed_x;
          z = new_speed_z;
          last_key = 77;
           break;
      case 190:
          //backward right
          x = -new_speed_x;
          z = -new_speed_z;
          last_key = 190;
          break;  
      default:
        pub = false;
    }
    //Assign the preview value to a variable
    last_speed_x = speed_x;
    last_speed_z = speed_z;
    // publish the command
    if (pub === true) {
      var twist = new ROSLIB.Message({
        angular : {
          x : 0,
          y : 0,
          z : z
        },
        linear : {
          x : x,
          y : y,
          z : 0
        }
      });
      cmdVel.publish(twist);

      // check for changes
      if (oldX !== x || oldY !== y || oldZ !== z) {
        that.emit('change', twist);
      }
    }
  };

  // handle the key
  var body = document.getElementsByTagName('body')[0];
  body.addEventListener('keydown', function(e) {
    that.handleKey(e.keyCode, true);
  }, false);
  body.addEventListener('keyup', function(e) {
    that.handleKey(e.keyCode, false);
  }, false);
  document.getElementById("key_curveleft").addEventListener('click',function(e){
    that.handleKey(85,true);
  },false);
  document.getElementById("key_up").addEventListener('click',function(e){
    that.handleKey(73,true);
  },false);
  document.getElementById("key_curveright").addEventListener('click',function(e){
    that.handleKey(79,true);
  },false);
  document.getElementById("key_left").addEventListener('click',function(e){
    that.handleKey(74,true);
  },false);
  document.getElementById("key_down").addEventListener('click',function(e){
    that.handleKey(188,true);
  },false);
  document.getElementById("key_right").addEventListener('click',function(e){
    that.handleKey(76,true);
  },false);
  document.getElementById("key_backcurveright").addEventListener('click',function(e){
    that.handleKey(77,true);
  },false);
  document.getElementById("key_backcurveleft").addEventListener('click',function(e){
    that.handleKey(190,true);
  },false);
  document.getElementById("key_stop").addEventListener('click',function(e){
    that.handleKey(75,true);
  },false);
  document.getElementById("key_L/A+").addEventListener('click',function(e){
    that.handleKey(81,true);
  },false);
  document.getElementById("key_L/A-").addEventListener('click',function(e){
    that.handleKey(90,true);
  },false);
  document.getElementById("key_L+").addEventListener('click',function(e){
    that.handleKey(87,true);
  },false);
  document.getElementById("key_L-").addEventListener('click',function(e){
    that.handleKey(88,true);
  },false);
  document.getElementById("key_A+").addEventListener('click',function(e){
    that.handleKey(69,true);
  },false);
  document.getElementById("key_A-").addEventListener('click',function(e){
    that.handleKey(67,true);
  },false);
};
KEYBOARDTELEOP.Teleop.prototype.__proto__ = EventEmitter2.prototype;
